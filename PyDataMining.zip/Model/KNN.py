import torch


def KNNClassfication(X_train, y_train, X_test, K=20, n_class=10):
    """
    Args:
        X_train, y_train: 训练样本的样本与标签
        X_test: 测试集样本
        k: 最近邻的样本个数
        n_class: 待分类的个数
    """
    dist = torch.cdist(X_train, X_test)
    _, neighbor_idx = dist.topk(K, dim=1, largest=False)
    neighbor_y = y_train[neighbor_idx]
    pred = []
    for i in range(len(X_test)):
        pred.append(torch.bincount(neighbor_y[i], minlength=n_class).argmax())
    return torch.Tensor(pred)