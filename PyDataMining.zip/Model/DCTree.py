""" 构造决策树 """

import numpy as np
import torch


def _entropy(y, c_num):
    count = torch.bincount(y, minlength=c_num)
    prob = count / count.sum()
    return -torch.nansum(prob * torch.log2(prob))


def _cumulative_calc_entropy(y, f_num, c_num, sort_idx):
    sort_y = torch.gather(y.repeat(f_num, 1).T, 0, sort_idx)
    cum_y = []
    for i in range(c_num):
        cum_y.append(torch.cumsum(sort_y == i, dim=0))
    cum_y = torch.stack(cum_y)
    prob_y = cum_y / cum_y.sum(dim=0, keepdim=True)
    entropy = -torch.nansum(prob_y * torch.log2(prob_y), dim=0)
    return entropy


class Node(object):
    def __init__(
            self, feature=None, threshold=None,
            value=None, impurity=None,
            left_children=None, right_children=None
    ):
        self.feature = feature
        self.threshold = threshold
        self.value = value
        self.impurity = impurity
        self.left_children = left_children
        self.right_children = right_children


class DecisionTreeClassifier(object):
    def __init__(self, num_feature, num_class, min_samples_split=2, min_impurity_decrease=0, max_depth=np.inf):

        """
        Args:
            num_feature: 输入特征的维度
            num_class: 分类的个数
            min_samples_split: 每个节点最少可分裂的样本数
            min_impurity_decrease: 每一次分类导致impurity下降的最小量
            max_depth: 树的最大的深度
        """

        self.num_feature = num_feature
        self.num_class = num_class
        self.root = None
        self.min_samples_split = min_samples_split
        self.min_impurity_decrease = min_impurity_decrease
        self.max_depth = max_depth
        self._criterion = _entropy
        self._cumulative_calc_criterion = _cumulative_calc_entropy

    def _find_split(self, X, y):
        N = len(X)
        min_sort_idx = X.argsort(dim=0)
        crit_min = self._cumulative_calc_criterion(y, self.num_feature, self.num_class, min_sort_idx)

        max_sort_idx = X.argsort(dim=0, descending=True)
        crit_max = self._cumulative_calc_criterion(y, self.num_feature, self.num_class, max_sort_idx)

        crit_max = torch.flip(crit_max, dims=(0,))

        count = torch.arange(1, N).unsqueeze(1)
        impurity = (count * crit_min[: -1] + (N - count) * crit_max[1:]) / N

        min_v, min_idx = impurity.min(dim=0)

        select_feature_idx = min_v.argmin()
        min_impurity = min_v[select_feature_idx]

        select_feature_sort_idx = min_idx[select_feature_idx]
        thresh_min = X[min_sort_idx[select_feature_sort_idx, select_feature_idx], select_feature_idx]
        thresh_max = X[min_sort_idx[select_feature_sort_idx + 1, select_feature_idx], select_feature_idx]
        threshold = 0.5 * (thresh_min + thresh_max)

        left_sample_idx = min_sort_idx[:select_feature_sort_idx + 1, select_feature_idx]
        right_sample_idx = min_sort_idx[select_feature_sort_idx + 1:, select_feature_idx]
        return select_feature_idx.item(), threshold.item(), min_impurity.item(), left_sample_idx, right_sample_idx

    def _build_tree(self, X, y, current_depth=0):
        n_samples = len(X)
        value = torch.bincount(y, minlength=self.num_class)
        impurity = self._criterion(y, self.num_class)

        if n_samples >= self.min_samples_split and current_depth <= self.max_depth:
            _result = self._find_split(X, y)
            select_feature_idx = _result[0]
            threshold = _result[1]
            min_impurity = _result[2]
            left_sample_idx, right_sample_idx = _result[3], _result[4]

            impurity_improvement = impurity - min_impurity

            if impurity_improvement > self.min_impurity_decrease:
                X_left, y_left = X[left_sample_idx], y[left_sample_idx]
                left_tree = self._build_tree(X_left, y_left, current_depth + 1)

                X_right, y_right = X[right_sample_idx], y[right_sample_idx]
                right_tree = self._build_tree(X_right, y_right, current_depth + 1)

                return Node(select_feature_idx, threshold, value, impurity, left_tree, right_tree)

        return Node(value=value, impurity=impurity)

    def fit(self, X, y):
        self.root = self._build_tree(X, y, current_depth=0)

    def predict_value(self, x, tree=None):
        if tree is None:
            tree = self.root

        if tree.left_children is None and tree.right_children is None:
            return tree.value
        feature = x[tree.feature]
        if feature <= tree.threshold:
            tree = tree.left_children
        else:
            tree = tree.right_children

        return self.predict_value(x, tree)

    def predict(self, X):
        y = torch.stack([self.predict_value(x) for x in X])
        y = y.argmax(dim=1)
        return y
