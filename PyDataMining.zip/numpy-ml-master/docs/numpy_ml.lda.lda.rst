``LDA``
=======

.. autoclass:: numpy_ml.lda.LDA
    :members:
    :undoc-members:
    :inherited-members:
