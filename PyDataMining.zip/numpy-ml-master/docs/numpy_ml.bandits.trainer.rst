Trainer
=======

``BanditTrainer``
------------------
.. autoclass:: numpy_ml.bandits.trainer.BanditTrainer
    :members:
    :undoc-members:
    :inherited-members:
