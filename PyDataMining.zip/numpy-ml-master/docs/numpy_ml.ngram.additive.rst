``AdditiveNGram``
-----------------

.. autoclass:: numpy_ml.ngram.AdditiveNGram
	:members:
	:undoc-members:
	:inherited-members:
