Multi-armed bandits
###################

.. toctree::
   :maxdepth: 3

   numpy_ml.bandits.bandits

   numpy_ml.bandits.policies

   numpy_ml.bandits.trainer
