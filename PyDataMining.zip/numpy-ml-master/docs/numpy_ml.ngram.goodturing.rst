``GoodTuringNGram``
-------------------

.. autoclass:: numpy_ml.ngram.GoodTuringNGram
	:members:
	:undoc-members:
	:inherited-members:
