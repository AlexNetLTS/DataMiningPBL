``KernelRegression``
#####################

.. autoclass:: numpy_ml.nonparametric.KernelRegression
	:members:
	:undoc-members:
	:inherited-members:
