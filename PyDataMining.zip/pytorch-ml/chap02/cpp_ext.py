import torch
import torch.utils.cpp_extension
import torch.nn.functional as F
source = """
#include <torch/extension.h>
torch::Tensor leakyrelu_forward(torch::Tensor input, float alpha) {
    auto pos = input.clamp_min(0);
    auto neg = input.clamp_max(0);
    return pos + alpha * neg;
}
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) { 
    m.def("forward", &leakyrelu_forward, "LeakyReLU forward");
}
""" 
leakyrelu_cpp = torch.utils.cpp_extension.load_inline(
    name="leakyrelu_cpp", cpp_sources=source, 
    verbose=True,
)


a = torch.randn(4, 3) 
print(a)
b = F.leaky_relu(a, 0.01)
print(b)
c = leakyrelu_cpp.forward(a, 0.01)
print(c)
