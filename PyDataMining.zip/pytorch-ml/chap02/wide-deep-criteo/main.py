from dataset import load_data, CriteoDataset
from model import WideDeepModel
import numpy as np
import torch.utils.data as data
import torch.nn.functional as F
import torch
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score

DEVICE = 'cpu'
EMB_DIM = 8
EPOCHS = 10
BATCH_SIZE = 32

raw_data, sparse_cols, dense_cols, keymap_size_list = load_data()
train_data, test_data = train_test_split(raw_data, test_size=0.8, random_state=2020)

train_loader = data.DataLoader(
    CriteoDataset(
        train_data, sparse_cols, dense_cols
    ),
    batch_size=BATCH_SIZE, shuffle=True
)
test_loader = data.DataLoader(
    CriteoDataset(
        test_data, sparse_cols, dense_cols
    ),
    batch_size=BATCH_SIZE, shuffle=False
)

net = WideDeepModel(
    len(sparse_cols),
    len(dense_cols),
    keymap_size_list,
    emb_dim=EMB_DIM,
    hidden_units=[100, 100]
)
net = net.to(DEVICE)
optimizer = torch.optim.Adam(net.parameters(), lr=1e-3, weight_decay=1e-4)


def train(epoch, net, loader, optimizer):
    net.train()
    summary = []
    for i, (sp_inp, ds_inp, target) in enumerate(loader):
        sp_inp = sp_inp.to(DEVICE)
        ds_inp = ds_inp.to(DEVICE)
        target = target.to(DEVICE)
        output = net(sp_inp, ds_inp).squeeze()
        loss = F.binary_cross_entropy(output, target)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        summary.append(loss.item())

    print('Epoch [%d], avg loss = %.6f' % (epoch, np.mean(summary)))


def test(net, loader):
    net.eval()
    all_targets = []
    all_results = []
    with torch.no_grad():
        for sp_inp, ds_inp, target in loader:
            sp_inp = sp_inp.to(DEVICE)
            ds_inp = ds_inp.to(DEVICE)
            output = net(sp_inp, ds_inp).squeeze()
            all_targets.append(target)
            all_results.append(output.to('cpu'))

    all_targets = torch.cat(all_targets)
    all_results = torch.cat(all_results)
    auc = roc_auc_score(all_targets, all_results)
    return auc


for epoch in range(EPOCHS):
    train(epoch, net, train_loader, optimizer)
    auc = test(net, test_loader)
    print('Testing @ Epoch [%d], '
          'auc score = %.4f' % (epoch, auc))
