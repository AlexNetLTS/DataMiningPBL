import pandas as pd
import torch.utils.data as data
import numpy as np


def sparse_to_category(feature):
    uniques = np.unique(feature)
    keymap = {k: i for i, k in enumerate(uniques)}
    categorical_feature = np.array([keymap[v] for v in feature])
    return categorical_feature, len(keymap)


def load_data():
    raw_data = pd.read_csv('criteo_sample.csv')

    sparse_cols = ['C' + str(i) for i in range(1, 27)]
    dense_cols = ['I' + str(i) for i in range(1, 14)]

    raw_data[sparse_cols] = raw_data[sparse_cols].fillna('-1')
    raw_data[dense_cols] = raw_data[dense_cols].fillna(0)

    keymap_size_list = []
    for feat in sparse_cols:
        feature = raw_data[feat].values
        cat_feature, keymap_size = sparse_to_category(feature)
        raw_data[feat] = cat_feature
        keymap_size_list.append(keymap_size)

    v_min = raw_data[dense_cols].min(axis=0)
    v_max = raw_data[dense_cols].max(axis=0)
    raw_data[dense_cols] = (raw_data[dense_cols] - v_min) / (v_max - v_min)
    return raw_data, sparse_cols, dense_cols, keymap_size_list


class CriteoDataset(data.Dataset):
    def __init__(self, raw_data, sparse_cols, dense_cols):
        self.raw_data = raw_data
        self.sparse_cols = sparse_cols
        self.dense_cols = dense_cols
    
    def __len__(self):
        return len(self.raw_data)
    
    def __getitem__(self, item):
        data_row = self.raw_data.iloc[item]
        sparse_feature = data_row[self.sparse_cols]
        dense_feature = data_row[self.dense_cols]
        label = data_row['Label']

        return sparse_feature.values.astype(np.int64), \
            dense_feature.values.astype(np.float32), \
            label.astype(np.float32)

        



