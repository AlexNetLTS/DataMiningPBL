import torch


class KNN:
    def __init__(self, K=10):
        self.K = K
    
    def fit(self, X, y):
        self._X = X.clone()
        self._y = y.clone()

    def predict(self, X):
        dist = torch.cdist(X, self._X)
        _, neighbor_idx = dist.topk(self.K, 1, largest=False)
        neighbor_y = self._y[neighbor_idx]
        preds = neighbor_y.mean(dim=1)
        return preds