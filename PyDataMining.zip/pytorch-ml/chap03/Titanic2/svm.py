import torch
import torch.nn as nn
import numpy as np

class LinearSVC():
    def __init__(self, input_dim, lambd=1e-4, batch_size=100, lr=0.1, iters=10000):
        self.input_dim = input_dim
        self.lambd = lambd
        self.batch_size = batch_size
        self.lr = lr
        self.iters = iters
        self.w = nn.Parameter(torch.randn(input_dim))
        self.b = nn.Parameter(torch.randn(1))
    
    def _loss(self, x, y):
        out = 1 - y * (torch.matmul(x, self.w) + self.b)
        out = torch.clamp(out, min=0)
        loss = 0.5 * self.lambd * torch.norm(self.w)**2 + out.mean()
        return loss
    
    def _zero_grad(self):
        if self.w.grad is not None:
            self.w.grad.zero_()
            self.b.grad.zero_()
    
    def _update_weights(self):
        self.w.data -= self.lr * self.w.grad.data
        self.b.data -= self.lr * self.b.grad.data
    
    def fit(self, data, labels):
        N = len(data)
        for i in range(self.iters):
            idx = np.random.choice(N, size=self.batch_size, replace=False)
            batch = data[idx]
            label = labels[idx]
            self._zero_grad()
            loss = self._loss(batch, label)
            loss.backward()
            self._update_weights()
    
    def predict(self, data):
        with torch.no_grad():
            score = torch.matmul(data, self.w.data) + self.b.data
                    
        return score


class DualSoftSVC():
    def __init__(self, n_samples, C=10, gamma=50, iters=50000, lr=1e-5):
        self.n_samples = n_samples
        self.C = C
        self.gamma = gamma
        self.alpha = nn.Parameter(torch.rand(n_samples))
        self.iters = iters
        self.lr = lr
    
    def _loss(self, x, y):
        # 计算损失函数
        loss1 = -self.alpha.sum()
        loss2 = 0.5 * (torch.matmul(x.T, (self.alpha * y))**2).sum()
        loss3 = self.gamma * (torch.dot(self.alpha, y)**2)
        loss = loss1 + loss2 + loss3
        return loss
    
    def _zero_grad(self):
        if self.alpha.grad is not None:
            self.alpha.grad.zero_()
    
    def _update_weights(self):
        self.alpha.data -= self.lr * self.alpha.grad.data
    
    def _clip_weights(self):
        # 截取alpha至[0, C]区间
        self.alpha.data = torch.clamp(self.alpha.data, min=0, max=self.C)
    
    def fit(self, X, y):
        for i in range(self.iters):
            self._zero_grad()
            self._clip_weights()
            loss = self._loss(X, y)
            loss.backward()
            self._update_weights()
        
        with torch.no_grad():
            self._clip_weights()
            # 计算W*的数据点指标
            idx_w = torch.where(self.alpha.data>0)[0]
            # 计算b*的数据点指标
            idx_b = torch.where((self.alpha.data>0)&(self.alpha.data<self.C))[0]
            self.w = torch.matmul(X[idx_w].T, self.alpha.data[idx_w] * y[idx_w])
            self.b = (y[idx_b] - torch.matmul(X[idx_b], self.w)).mean()
    
    def predict(self, data):    
        with torch.no_grad():
            score = torch.matmul(data, self.w) + self.b
        
        return score