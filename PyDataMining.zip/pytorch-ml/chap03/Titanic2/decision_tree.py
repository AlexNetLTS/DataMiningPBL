import torch
import numpy as np

def _entropy(y, c_num):
    # impurity function
    count = torch.bincount(y, minlength=c_num)
    prob = count / count.sum()
    return -torch.nansum(prob * torch.log2(prob))
    
def _cumulative_calc_entropy(y, f_num, c_num, sort_idx):
    # sort_idx是特征各个维度按照升序排序后的指标
    # sort_y是按照特征值顺序排列后对应的标签值
    sort_y = torch.gather(y.repeat(f_num, 1).T, 0, sort_idx)
    cum_y = []
    # 可以累加计算属于每一类的情况
    for i in range(c_num):
        cum_y.append(torch.cumsum(sort_y==i, dim=0))
    cum_y = torch.stack(cum_y)
    # 算出了按照特征顺序排列后，每个分裂处，左子集样本的各类比例
    prob_y = cum_y / cum_y.sum(dim=0, keepdims=True)
    # 算出了每个分裂处左子集的impurity
    entropy = - torch.nansum(prob_y * torch.log2(prob_y), dim=0)  # N_sample * f_num
    return entropy

class Node:
    def __init__(self, feature=None, threshold=None, value=None, 
                 impurity=None, left_children=None, right_children=None):
        self.feature = feature
        self.threshold = threshold
        self.value = value
        self.impurity = impurity
        self.left_children = left_children
        self.right_children = right_children

class DecisionTreeClassifier:
    def __init__(self, num_feature, num_class, 
                 min_samples_split=2, min_impurity_decrease=0, max_depth=np.inf):
        '''
        Args:
            num_feature, 输入特征维度
            num_class, 分类个数
            min_samples_split, 每个节点最少可分裂样本数
            min_impurity_decrease, 每一次分类导致impurity下降的最小量
            max_depth, 树的最大深度
        '''
        self.num_feature = num_feature
        self.num_class = num_class
        self.root = None  # 根节点
        self.min_samples_split = min_samples_split
        self.min_impurity_decrease = min_impurity_decrease
        self.max_depth = max_depth
        self._criterion = _entropy  # 计算impurity函数
        self._cumulative_calc_criterion = _cumulative_calc_entropy  # 计算各个阈值分裂后的impurity
 
    def _find_split(self, X, y):
        N = len(X)
        # 按照升序排列，算出各个分裂阈值的左子集impurity
        min_sort_idx = X.argsort(dim=0)
        crit_min = self._cumulative_calc_criterion(y, self.num_feature, self.num_class, min_sort_idx)

        # 按照降序排列，算出各个分裂阈值的右子集impurity
        max_sort_idx = X.argsort(dim=0, descending=True)
        crit_max = self._cumulative_calc_criterion(y, self.num_feature, self.num_class, max_sort_idx)
        # 注意这里需要再次反转过来，以便于与crit_min对齐
        crit_max = torch.flip(crit_max, dims=(0,))

        # 按照左右子集样本比例加权计算impurity
        count = torch.arange(1, N).unsqueeze(1)
        impurity = (count * crit_min[:-1] + (N - count) * crit_max[1:]) / N

        # 找到各特征列最小的impurity处，及对应的分裂指标
        min_v, min_idx = impurity.min(dim=0)

        # 找到所有特征列中最小的impurity
        select_feature_idx = min_v.argmin()
        min_impurity = min_v[select_feature_idx]

        # 根据选取特征列，阈值选择为相邻两个特征值的中间值
        select_feature_sort_idx = min_idx[select_feature_idx]
        thresh_min = X[min_sort_idx[select_feature_sort_idx, select_feature_idx], select_feature_idx]
        thresh_max = X[min_sort_idx[select_feature_sort_idx+1, select_feature_idx], select_feature_idx]
        threshold = 0.5 * (thresh_min + thresh_max)

        # 获得左子树样本和右子树样本
        left_sample_idx = min_sort_idx[:select_feature_sort_idx+1, select_feature_idx]
        right_sample_idx = min_sort_idx[select_feature_sort_idx+1:, select_feature_idx]
        return select_feature_idx.item(), threshold.item(), min_impurity.item(), left_sample_idx, right_sample_idx
    
    def _build_tree(self, X, y, current_depth=0):
        # current_depth指示当前节点所处深度
        n_samples = len(X)
        
        # 计算分配到该节点的value和impurity
        value = torch.bincount(y, minlength=self.num_class)
        impurity = self._criterion(y, self.num_class)
        
        # 如果符合分裂条件
        if n_samples >= self.min_samples_split and current_depth <= self.max_depth:
            # 调用分裂节点算法
            _result = self._find_split(X, y)
            select_feature_idx = _result[0] # 选取特征维度指标
            threshold = _result[1]  # 阈值
            min_impurity = _result[2]   # 最小的分裂后杂质
            left_sample_idx, right_sample_idx = _result[3], _result[4]  # 左右子树样本
        
            impurity_improvement = impurity - min_impurity  # 计算impurity降低程度
            
            if impurity_improvement > self.min_impurity_decrease:   # 如果符合条件
                
                # 递归调用_build_tree算法，构建左右子树
                X_left, y_left = X[left_sample_idx], y[left_sample_idx]
                left_tree = self._build_tree(X_left, y_left, current_depth+1)
                
                X_right, y_right = X[right_sample_idx], y[right_sample_idx]
                right_tree = self._build_tree(X_right, y_right, current_depth+1)
                
                # 返回该节点信息
                return Node(select_feature_idx, threshold, value, impurity, left_tree, right_tree)
        
        # 如果不符合条件，则叶子节点，只返回包含value和impurity的节点
        return Node(value=value, impurity=impurity)
        
    def fit(self, X, y):
        self.root = self._build_tree(X, y, current_depth=0)
    
    def predict_value(self, x, tree=None):
        # 预测单个样本的输出
        if tree is None:
            tree = self.root
        
        if tree.left_children is None and tree.right_children is None:
            # 如果叶子节点，返回value
            return tree.value
        
        # 获取该节点分裂特征维度
        feature = x[tree.feature]

        # 判断是否进入左子树还是右子树
        if feature <= tree.threshold:
            tree = tree.left_children
        else:
            tree = tree.right_children
        
        return self.predict_value(x, tree)
    
    def predict(self, X):
        y = torch.stack([self.predict_value(x) for x in X])
        y = y / y.sum(dim=1, keepdims=True)
        return y
    

def _variance(y):
    y_mean = y.mean()
    var = ((y - y_mean)**2).mean()
    return var
    
def _cumulative_calc_variance(y, f_num, sort_idx):
    sort_y = torch.gather(y.repeat(f_num, 1).T, 0, sort_idx)
    count = torch.arange(1, len(y)+1).reshape(-1, 1)
    cum_sum = torch.cumsum(sort_y, dim=0)
    cum_mean = cum_sum / count
    square = torch.cumsum(sort_y**2, dim=0)
    var = (square - 2 * cum_mean * cum_sum) / count + cum_mean**2
    return var



class DecisionTreeRegressor:
    def __init__(self, num_feature,
                 min_samples_split=2, min_impurity_decrease=0, max_depth=np.inf):
        self.num_feature = num_feature
        self.root = None
        self.min_samples_split = min_samples_split
        self.min_impurity_decrease = min_impurity_decrease
        self.max_depth = max_depth
        self._criterion = _variance
        self._cumulative_calc_criterion = _cumulative_calc_variance
 
    def _find_split(self, X, y):
        N = len(X)
        min_sort_idx = X.argsort(dim=0)
        crit_min = self._cumulative_calc_criterion(y, self.num_feature, min_sort_idx)

        max_sort_idx = X.argsort(dim=0, descending=True)
        crit_max = self._cumulative_calc_criterion(y, self.num_feature, max_sort_idx)
        crit_max = torch.flip(crit_max, dims=(0,))

        count = torch.arange(1, N).unsqueeze(1)
        impurity = (count * crit_min[:-1] + (N - count) * crit_max[1:]) / N

        min_v, min_idx = impurity.min(dim=0)
        
        select_feature_idx = min_v.argmin()
        min_impurity = min_v[select_feature_idx]

        select_feature_sort_idx = min_idx[select_feature_idx]
        thresh_min = X[min_sort_idx[select_feature_sort_idx, select_feature_idx], select_feature_idx]
        thresh_max = X[min_sort_idx[select_feature_sort_idx+1, select_feature_idx], select_feature_idx]
        threshold = 0.5 * (thresh_min + thresh_max)

        left_sample_idx = min_sort_idx[:select_feature_sort_idx+1, select_feature_idx]
        right_sample_idx = min_sort_idx[select_feature_sort_idx+1:, select_feature_idx]
        return select_feature_idx.item(), threshold.item(), min_impurity.item(), left_sample_idx, right_sample_idx
    
    def _build_tree(self, X, y, current_depth=0):
        
        n_samples = len(X)
        value = y.mean()
        impurity = self._criterion(y)
                
        if n_samples >= self.min_samples_split and current_depth <= self.max_depth:
            _result = self._find_split(X, y)
            select_feature_idx = _result[0]
            threshold = _result[1]
            min_impurity = _result[2]
            left_sample_idx, right_sample_idx = _result[3], _result[4]
        
            impurity_improvement = impurity - min_impurity
            
            if impurity_improvement > self.min_impurity_decrease:
                
                X_left, y_left = X[left_sample_idx], y[left_sample_idx]
                left_tree = self._build_tree(X_left, y_left, current_depth+1)
                
                X_right, y_right = X[right_sample_idx], y[right_sample_idx]
                right_tree = self._build_tree(X_right, y_right, current_depth+1)
                
                return Node(select_feature_idx, threshold, value, impurity, left_tree, right_tree)
        
        return Node(value=value, impurity=impurity)
    
    def fit(self, X, y):
        self.root = self._build_tree(X, y, current_depth=0)
    
    def predict_value(self, x, tree=None):
        if tree is None:
            tree = self.root
        
        if tree.left_children is None and tree.right_children is None:
            return tree.value
        
        if x.dim() > 0:
            feature = x[tree.feature]
        else:
            feature = x
        if feature <= tree.threshold:
            tree = tree.left_children
        else:
            tree = tree.right_children
        
        return self.predict_value(x, tree)
    
    def predict(self, X):
        y = torch.Tensor([self.predict_value(x) for x in X])
        return y
