import torch
from decision_tree import DecisionTreeClassifier, DecisionTreeRegressor
import numpy as np


class RandomForest:
    def __init__(self, num_feature, num_class, n_estimators=10, max_features=None,
                 min_samples_split=2, min_impurity_decrease=0, max_depth=np.inf):
        self.num_feature = num_feature
        self.num_class = num_class
        self.n_estimators = n_estimators
        self.min_samples_split = min_samples_split
        self.min_impurity_decrease = min_impurity_decrease
        self.max_depth = max_depth
        
        if not max_features:
            self.max_features = int(np.sqrt(self.num_feature))
        else:
            self.max_features = max_features
            
        self.trees = []
        for _ in range(self.n_estimators):
            self.trees.append(
                DecisionTreeClassifier(
                    self.max_features, num_class, min_samples_split, min_impurity_decrease, max_depth
                )
            )
    
    def fit(self, X, y):  
        N = len(X)
        for i in range(self.n_estimators):
            idx = np.random.choice(range(N), size=N//2)
            feature_idx = np.random.choice(range(self.num_feature), size=self.max_features)
            self.trees[i].feature_idx = feature_idx
            
            X_subset = X[idx][:, feature_idx]
            y_subset = y[idx]
            self.trees[i].fit(X_subset, y_subset)
    
    def predict(self, X):
        y_preds = []
        for tree in self.trees:
            idx = tree.feature_idx
            y_preds.append(tree.predict(X[:, idx]))
        
        y_preds = torch.stack(y_preds)  # T * N * K
        y_preds = y_preds.mean(dim=0)
        return y_preds


class SquareLoss:
    def loss(self, y, y_pred):
        return 0.5 * ((y - y_pred)**2)

    def gradient(self, y, y_pred):
        return -(y - y_pred)

        
class GradientBoostingRegressor:
    def __init__(self, num_feature, lr=0.1, n_estimators=10, 
                 min_samples_split=2, min_impurity_decrease=0, max_depth=np.inf):
        self.num_feature = num_feature
        self.lr = lr
        self.n_estimators = n_estimators
        self.min_samples_split = min_samples_split
        self.min_impurity_decrease = min_impurity_decrease
        self.max_depth = max_depth
        self.loss = SquareLoss()
        
        self.trees = []
        for _ in range(self.n_estimators):
            self.trees.append(
                DecisionTreeRegressor(
                    num_feature, min_samples_split, 
                    min_impurity_decrease, max_depth
                )
            )
    
    def fit(self, X, y):
        y_pred = torch.zeros_like(y)
        for i in range(self.n_estimators):
            gradient = self.loss.gradient(y, y_pred)
            self.trees[i].fit(X, gradient)
            update = self.trees[i].predict(X)
            # Update y prediction
            y_pred -= self.lr * update
    
    
    def predict(self, X):
        y_pred = torch.zeros(len(X))
        for tree in self.trees:
            update = tree.predict(X)
            update = self.lr * update
            y_pred = y_pred - update
        
        return y_pred